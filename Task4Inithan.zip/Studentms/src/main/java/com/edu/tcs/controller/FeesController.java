package com.edu.tcs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.edu.tcs.model.Student;



@RestController
@RequestMapping("/feesms")
public class FeesController {
	
	@Autowired
	public RestTemplate resttemplate;
	
	//An API to pay fees for a student
		@PostMapping("/studentFeesPay")
		public Student studentFeesPay(@RequestBody Student student) {
		return resttemplate.postForObject("http://localhost:9091/fees/studentFeesPay", student, Student.class);
		}
		
		 //An API to fetch all students 
		 @GetMapping("/api/fetchStudentFees/{id}") 
		 public Student fetchStudentFees(@PathVariable Integer id){
		 return resttemplate.getForObject("http://localhost:9091/fees/fetchStudentFees/" + id, Student.class); 
		 }
		 

}
