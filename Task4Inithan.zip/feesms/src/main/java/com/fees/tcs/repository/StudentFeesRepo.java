package com.fees.tcs.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fees.tcs.entity.Student;

@Repository
public interface StudentFeesRepo extends JpaRepository<Student, Integer>{
	
	
	@Query("SELECT NEXTVAL('student_seq')")
	int getStudentId();

}
