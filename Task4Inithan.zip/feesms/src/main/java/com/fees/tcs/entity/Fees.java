package com.fees.tcs.entity;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "Fees")
public class Fees implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "fee")
	@SequenceGenerator(name = "fee", sequenceName = "fees_seq", allocationSize = 1)
	private int fee_ID;
    @ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Student_ID", insertable=false, updatable=false)
    @JsonIgnore
	private Student student;
    private int student_ID;
    private String fee_Type;
    private int amount;
    private Date payment_Date;
    private String payment_Method;
    private String transaction_ID;
    private Date due_Date;
    private String status;
	public int getFee_ID() {
		return fee_ID;
	}
	public void setFee_ID(int fee_ID) {
		this.fee_ID = fee_ID;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}

	
	  public int getStudent_ID() { return student_ID; } public void
	  setStudent_ID(int student_ID) { this.student_ID = student_ID; }
	 
	public String getFee_Type() {
		return fee_Type;
	}
	public void setFee_Type(String fee_Type) {
		this.fee_Type = fee_Type;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Date getPayment_Date() {
		return payment_Date;
	}
	public void setPayment_Date(Date payment_Date) {
		this.payment_Date = payment_Date;
	}
	public String getPayment_Method() {
		return payment_Method;
	}
	public void setPayment_Method(String payment_Method) {
		this.payment_Method = payment_Method;
	}
	public String getTransaction_ID() {
		return transaction_ID;
	}
	public void setTransaction_ID(String transaction_ID) {
		this.transaction_ID = transaction_ID;
	}
	public Date getDue_Date() {
		return due_Date;
	}
	public void setDue_Date(Date due_Date) {
		this.due_Date = due_Date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + amount;
		result = prime * result + ((due_Date == null) ? 0 : due_Date.hashCode());
		result = prime * result + fee_ID;
		result = prime * result + ((fee_Type == null) ? 0 : fee_Type.hashCode());
		result = prime * result + ((payment_Date == null) ? 0 : payment_Date.hashCode());
		result = prime * result + ((payment_Method == null) ? 0 : payment_Method.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((student == null) ? 0 : student.hashCode());
		result = prime * result + student_ID;
		result = prime * result + ((transaction_ID == null) ? 0 : transaction_ID.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fees other = (Fees) obj;
		if (amount != other.amount)
			return false;
		if (due_Date == null) {
			if (other.due_Date != null)
				return false;
		} else if (!due_Date.equals(other.due_Date))
			return false;
		if (fee_ID != other.fee_ID)
			return false;
		if (fee_Type == null) {
			if (other.fee_Type != null)
				return false;
		} else if (!fee_Type.equals(other.fee_Type))
			return false;
		if (payment_Date == null) {
			if (other.payment_Date != null)
				return false;
		} else if (!payment_Date.equals(other.payment_Date))
			return false;
		if (payment_Method == null) {
			if (other.payment_Method != null)
				return false;
		} else if (!payment_Method.equals(other.payment_Method))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (student == null) {
			if (other.student != null)
				return false;
		} else if (!student.equals(other.student))
			return false;
		
		  if (student_ID != other.student_ID) return false;
		 
		if (transaction_ID == null) {
			if (other.transaction_ID != null)
				return false;
		} else if (!transaction_ID.equals(other.transaction_ID))
			return false;
		return true;
	}
	public Fees(int fee_ID, Student student, int student_ID, String fee_Type, int amount, Date payment_Date,
			String payment_Method, String transaction_ID, Date due_Date, String status) {
		super();
		this.fee_ID = fee_ID;
		this.student = student;
		this.student_ID = student_ID;
		this.fee_Type = fee_Type;
		this.amount = amount;
		this.payment_Date = payment_Date;
		this.payment_Method = payment_Method;
		this.transaction_ID = transaction_ID;
		this.due_Date = due_Date;
		this.status = status;
	}
	public Fees() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Fees [fee_ID=" + fee_ID + ", student=" + student + ", student_ID=" + student_ID + ", fee_Type="
				+ fee_Type + ", amount=" + amount + ", payment_Date=" + payment_Date + ", payment_Method="
				+ payment_Method + ", transaction_ID=" + transaction_ID + ", due_Date=" + due_Date + ", status="
				+ status + "]";
	}
	
	

}
