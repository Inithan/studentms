CREATE TABLE Student (
    Student_ID INT PRIMARY KEY,
    First_Name VARCHAR(50),
    Last_Name VARCHAR(50),
    DOB DATE,
    Gender VARCHAR(10),
    Address VARCHAR(255),
    Email VARCHAR(100),
    Major_Program VARCHAR(50),
    GPA DECIMAL(3, 2),
    Status VARCHAR(20)
);
commit;

create sequence student_seq start with 1 maxvalue 999;
commit;
INSERT INTO Student VALUES
(1000, 'John', 'Doe', '1995-03-15', 'Male', '123 Main St, Cityville', 'john.doe@email.com', 'Computer Science', 3.5, 'Active'),
(2000, 'Jane', 'Smith', '1998-07-22', 'Female', '456 Oak St, Townsville', 'jane.smith@email.com', 'Psychology', 3.2, 'Graduated'),
(3000, 'Bob', 'Johnson', '1997-01-10', 'Male', '789 Pine St, Villagetown', 'bob.johnson@email.com', 'Business Administration', 3.8, 'Active'),
(4000, 'Alice', 'Williams', '1996-05-03', 'Female', '101 Cedar St, Hamletville', 'alice.williams@email.com', 'Physics', 3.9, 'Graduated'),
(5000, 'Charlie', 'Brown', '1999-11-28', 'Male', '202 Birch St, Riverside', 'charlie.brown@email.com', 'English Literature', 3.1, 'Active');
commit;

CREATE TABLE Fees (
    Fee_ID INT PRIMARY KEY,
    Student_ID INT,
    Fee_Type VARCHAR(50),
    Amount DECIMAL(10, 2),
    Payment_Date DATE,
    Payment_Method VARCHAR(50),
    Transaction_ID VARCHAR(100),
    Due_Date DATE,
    Status VARCHAR(20),
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID)
);

commit;

create sequence fees_seq start with 1 maxvalue 999;
commit;
create sequence for_seq start with 1 maxvalue 999;
commit;

INSERT INTO Fees VALUES
(1000, 1000, 'Tuition', 1500.00, '2023-01-05', 'Credit Card', 'TRX123', '2023-02-05', 'Paid'),
(2000, 2000, 'Registration', 200.00, '2023-01-10', 'Cash', 'TRX456', '2023-02-10', 'Paid'),
(3000, 3000, 'Library', 50.00, '2023-01-15', 'Online Transfer', 'TRX789', '2023-02-15', 'Pending'),
(4000, 4000, 'Tuition', 1200.00, '2023-01-20', 'Credit Card', 'TRX101', '2023-02-20', 'Overdue'),
(5000, 5000, 'Miscellaneous', 75.00, '2023-01-25', 'Cash', 'TRX202', '2023-02-25', 'Paid');
commit;


